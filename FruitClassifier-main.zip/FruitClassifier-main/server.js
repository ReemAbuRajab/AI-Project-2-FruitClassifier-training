const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const NeuralNetwork = require('./neuralNetwork');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

app.use(express.static('public'));

// Declare the network variable in the outer scope
let network;

// Utility function to convert color names to numerical values
function colorToNumber(color) {
  const colors = {
    red: 0,
    green: 1,
    blue: 2,
    yellow: 3,
    purple: 4,
    orange: 5
    // Add more colors as needed
  };
  return colors[color.toLowerCase()] || 0;
}

// Route to train the model
app.post('/train', async (req, res) => {
  try {
    const { inputData, hiddenNeurons, activationFunction, outputActivationFunction, learningRate, maxEpochs, goal } = req.body;

    // Initialize the network with the specified configuration
    network = new NeuralNetwork(2, hiddenNeurons, 5, activationFunction, outputActivationFunction);

    // Prepare the training data
    const trainingData = inputData.map(d => ({
      inputs: [d.sweetness, colorToNumber(d.color)],
      outputs: fruitToOneHot(d.fruit)
    }));

    // Train the model
    network.train(trainingData, learningRate, maxEpochs, goal);

    res.json({ message: 'Model trained successfully' });
  } catch (error) {
    console.error('Error during model training:', error);
    res.status(400).json({ error: error.message });
  }
});

// Helper function to convert fruit names to one-hot encoded arrays
function fruitToOneHot(fruit) {
  switch (fruit.toLowerCase()) {
    case "apple": return [1, 0, 0, 0, 0];
    case "banana": return [0, 1, 0, 0, 0];
    case "orange": return [0, 0, 1, 0, 0];
    case "grape": return [0, 0, 0, 1, 0];
    default: return [0, 0, 0, 0, 1];
  }
}

// Define a fruits array for mapping prediction indices to fruit names

// const fruits = ['apple', 'banana', 'orange', 'grape', 'pineapple'];

// const testData = [
//   { "fruit": "apple", "sweetness": 5, "color": "green" },
//   { "fruit": "banana", "sweetness": 6, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 6, "color": "orange" },
//   { "fruit": "grape", "sweetness": 10, "color": "purple" },
//   { "fruit": "pineapple", "sweetness": 4, "color": "green" },
//   { "fruit": "apple", "sweetness": 5, "color": "green" },
//   { "fruit": "banana", "sweetness": 4, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 4, "color": "orange" },
//   { "fruit": "grape", "sweetness": 8, "color": "green" },
//   { "fruit": "pineapple", "sweetness": 5, "color": "yellow" },
//   { "fruit": "apple", "sweetness": 7, "color": "red" },
//   { "fruit": "banana", "sweetness": 5, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 5, "color": "orange" },
//   { "fruit": "grape", "sweetness": 8, "color": "purple" },
//   { "fruit": "pineapple", "sweetness": 5, "color": "yellow" },
//   { "fruit": "apple", "sweetness": 7, "color": "yellow" },
//   { "fruit": "banana", "sweetness": 3, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 6, "color": "orange" },
//   { "fruit": "grape", "sweetness": 9, "color": "green" },
//   { "fruit": "pineapple", "sweetness": 5, "color": "green" },
//   { "fruit": "apple", "sweetness": 5, "color": "green" },
//   { "fruit": "banana", "sweetness": 6, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 6, "color": "orange" },
//   { "fruit": "grape", "sweetness": 10, "color": "green" },
//   { "fruit": "pineapple", "sweetness": 6, "color": "green" },
//   { "fruit": "apple", "sweetness": 7, "color": "green" },
//   { "fruit": "banana", "sweetness": 4, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 5, "color": "orange" },
//   { "fruit": "grape", "sweetness": 8, "color": "green" },
//   { "fruit": "pineapple", "sweetness": 7, "color": "yellow" },
//   { "fruit": "apple", "sweetness": 7, "color": "red" },
//   { "fruit": "banana", "sweetness": 3, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 6, "color": "orange" },
//   { "fruit": "grape", "sweetness": 10, "color": "purple" },
//   { "fruit": "pineapple", "sweetness": 4, "color": "green" },
//   { "fruit": "apple", "sweetness": 5, "color": "red" },
//   { "fruit": "banana", "sweetness": 3, "color": "yellow" },
//   { "fruit": "orange", "sweetness": 5, "color": "orange" },
//   { "fruit": "grape", "sweetness": 8, "color": "green" },
//   { "fruit": "pineapple", "sweetness": 4, "color": "green" }
// ];

// // Route for making predictions
// app.post('/predict', (req, res) => {
//   try {
//     const { sweetness, color } = req.body;
//     if (!network) {
//       throw new Error('The model has not been trained yet.');
//     }

//     const prediction = network.predict([parseFloat(sweetness), colorToNumber(color)]);

//     // Calculate accuracy on the test dataset
//     let correctPredictions = 0;
//     testData.forEach(data => {
//       const testPrediction = network.predict([parseFloat(data.sweetness), colorToNumber(data.color)]);

//       if (!Array.isArray(testPrediction)) {
//         console.error("Prediction is not an array:", testPrediction);
//         return;
//       }

//       const predictedFruitIndex = testPrediction.indexOf(Math.max(...testPrediction));
//       const predictedFruit = fruits[predictedFruitIndex];

//       if (predictedFruit && data.fruit.toLowerCase() === predictedFruit.toLowerCase()) {
//         correctPredictions++;
//       }
//     });

//     const accuracy = correctPredictions / testData.length;

//     res.json({
//       prediction: prediction || [],
//       accuracy
//     });
//   } catch (error) {
//     console.error('Error during prediction:', error);
//     res.status(400).json({ error: error.message });
//   }
// });

app.post('/predict', (req, res) => {
  try {
    const { sweetness, color } = req.body;
    if (!network) {
      throw new Error('The model has not been trained yet.');
    }

    // Making a prediction based on the provided sweetness and color
    const prediction = network.predict([parseFloat(sweetness), colorToNumber(color)]);

    // Sending the prediction result as a response
    res.json({ prediction });
  } catch (error) {
    console.error('Error during prediction:', error);
    res.status(400).json({ error: error.message });
  }
});

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Fruit Classifier app listening at http://localhost:${port}`);
});
