const fs = require('fs');

const fruitProperties = {
    apple: { sweetnessRange: [5, 7], colors: ["red", "green", "yellow"] },
    banana: { sweetnessRange: [3, 6], colors: ["yellow"] },
    orange: { sweetnessRange: [4, 6], colors: ["orange"] },
    grape: { sweetnessRange: [8, 10], colors: ["purple", "green"] },
    pineapple: { sweetnessRange: [4, 7], colors: ["yellow", "green"] }
};
const data = [];

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

for (let i = 0; i < 90; i++) {
    const fruit = Object.keys(fruitProperties)[i % Object.keys(fruitProperties).length];
    const properties = fruitProperties[fruit];
    const sweetness = getRandomInt(properties.sweetnessRange[0], properties.sweetnessRange[1]);
    const color = properties.colors[Math.floor(Math.random() * properties.colors.length)];
    data.push({ fruit: fruit, sweetness, color });
}

fs.writeFile('fruits.json', JSON.stringify(data, null, 2), (err) => {
    if (err) throw err;
    console.log('The file has been saved!');
});
