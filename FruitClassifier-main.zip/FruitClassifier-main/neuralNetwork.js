class NeuralNetwork {
    constructor(inputSize, hiddenLayerSize, outputSize, hiddenLayerActivationFunc, outputLayerActivationFunc) {
        this.inputSize = inputSize;
        this.hiddenLayerSize = hiddenLayerSize;
        this.outputSize = outputSize;
        this.hiddenLayerActivationFunction = hiddenLayerActivationFunc;
        this.outputLayerActivationFunction = outputLayerActivationFunc;

        this.initializeWeightsAndBiases();
    }

    initializeWeightsAndBiases() {
        this.weightsInputHidden = this.createRandomMatrix(this.inputSize, this.hiddenLayerSize);
        this.weightsHiddenOutput = this.createRandomMatrix(this.hiddenLayerSize, this.outputSize);
        this.hiddenLayerBias = this.createRandomArray(this.hiddenLayerSize);
        this.outputLayerBias = this.createRandomArray(this.outputSize);
    }

    createRandomMatrix(rows, columns) {
        const Fi = rows === this.inputSize ? this.hiddenLayerSize : this.outputSize;
        const range = 2.4 / Fi;

        return Array.from({ length: rows }, () =>
            Array.from({ length: columns }, () => Math.random() * range * 2 - range));
    }

    createRandomArray(length) {
        return Array.from({ length }, () => Math.random() * 2 - 1);
    }

    applyActivationFunction(x, layerType) {
        let activationFunction;
        if (layerType === 'hidden') {
            activationFunction = this.hiddenLayerActivationFunction;
            switch (activationFunction) {
                case 'sigmoid':
                    return 1 / (1 + Math.exp(-x));
                case 'tanh':
                    return Math.tanh(x);
                case 'relu':
                    return Math.max(0, x);
                default:
                    throw new Error('Unknown activation function for hidden layer: ' + activationFunction);
            }
        } else if (layerType === 'output') {
            activationFunction = this.outputLayerActivationFunction;
            switch (activationFunction) {
                case 'sigmoid':
                    if (Array.isArray(x)) {
                        return x.map(val => 1 / (1 + Math.exp(-val)));
                    }
                    return 1 / (1 + Math.exp(-x));
                case 'softmax':
                    return this.softmax(x);
                default:
                    throw new Error('Unknown activation function for output layer: ' + activationFunction);
            }
        } else {
            throw new Error('Invalid layer type: ' + layerType);
        }
    }

    softmax(outputs) {
        if (!Array.isArray(outputs)) {
            throw new Error('Softmax input must be an array.');
        }

        const max = Math.max(...outputs);
        const exps = outputs.map(o => Math.exp(o - max));
        const sum = exps.reduce((acc, val) => acc + val, 0);
        return exps.map(e => e / sum);
    }

    derivativeActivationFunction(x, layerType) {
        let activationFunction;
        if (layerType === 'hidden') {
            activationFunction = this.hiddenLayerActivationFunction;
        } else if (layerType === 'output') {
            activationFunction = this.outputLayerActivationFunction;
        } else {
            throw new Error('Invalid layer type: ' + layerType);
        }

        switch (activationFunction) {
            case 'sigmoid':
                // Derivative of sigmoid: sigmoid(x) * (1 - sigmoid(x))
                return x * (1 - x);
            case 'tanh':
                // Derivative of tanh: 1 - (tanh(x))^2
                return 1 - x * x;
            case 'relu':
                // Derivative of ReLU: 1 for x > 0, otherwise 0
                return x > 0 ? 1 : 0;
            default:
                throw new Error('Unknown derivative for activation function: ' + activationFunction);
        }
    }

    forwardPropagate(inputs) {
        this.hiddenLayerOutputs = new Array(this.hiddenLayerSize);
        this.finalOutputs = new Array(this.outputSize);

        // Calculate outputs for the hidden layer
        for (let i = 0; i < this.hiddenLayerSize; i++) {
            let sum = 0;
            for (let j = 0; j < this.inputSize; j++) {
                sum += inputs[j] * this.weightsInputHidden[j][i];
            }
            this.hiddenLayerOutputs[i] = this.applyActivationFunction(sum + this.hiddenLayerBias[i], 'hidden');
        }

        // Calculate outputs for the output layer
        for (let i = 0; i < this.outputSize; i++) {
            let sum = 0;
            for (let j = 0; j < this.hiddenLayerSize; j++) {
                sum += this.hiddenLayerOutputs[j] * this.weightsHiddenOutput[j][i];
            }
            this.finalOutputs[i] = sum + this.outputLayerBias[i];
        }

        // Apply activation function to the entire output array
        this.finalOutputs = this.applyActivationFunction(this.finalOutputs, 'output');
    }

    backpropagate(input, expectedOutput, learningRate) {
        // Calculate error for output layer
        let outputErrors = new Array(this.outputSize);
        for (let i = 0; i < this.outputSize; i++) {
            outputErrors[i] = expectedOutput[i] - this.finalOutputs[i];
        }

        // Calculate error for hidden layer
        let hiddenErrors = new Array(this.hiddenLayerSize);
        for (let i = 0; i < this.hiddenLayerSize; i++) {
            hiddenErrors[i] = 0;
            for (let j = 0; j < this.outputSize; j++) {
                hiddenErrors[i] += outputErrors[j] * this.weightsHiddenOutput[i][j];
            }
        }

        // Update weights for hidden-output layer
        for (let i = 0; i < this.hiddenLayerSize; i++) {
            for (let j = 0; j < this.outputSize; j++) {
                this.weightsHiddenOutput[i][j] += learningRate * this.hiddenLayerOutputs[i] * outputErrors[j];
            }
            this.outputLayerBias[i] += learningRate * outputErrors[i];
        }

        // Update weights for input-hidden layer
        for (let i = 0; i < this.inputSize; i++) {
            for (let j = 0; j < this.hiddenLayerSize; j++) {
                const derivative = this.derivativeActivationFunction(this.hiddenLayerOutputs[j], 'hidden');
                this.weightsInputHidden[i][j] += learningRate * input[i] * hiddenErrors[j] * derivative;
                this.hiddenLayerBias[j] += learningRate * hiddenErrors[j] * derivative;
            }
        }
    }

    train(trainingData, learningRate, maxEpochs, errorThreshold) {
        for (let epoch = 0; epoch < maxEpochs; epoch++) {
            let sumError = 0;
            for (let data of trainingData) {
                const inputs = data.inputs;
                const outputs = data.outputs;
                this.forwardPropagate(inputs);
                sumError += this.calculateError(outputs);
                this.backpropagate(inputs, outputs, learningRate);
            }

            if (sumError < errorThreshold) {
                console.log(`Training stopped early at epoch ${epoch + 1}`);
                break;
            }
        }
    }

    calculateError(expectedOutput) {
        return this.finalOutputs.reduce((sum, output, i) => sum + Math.pow(expectedOutput[i] - output, 2), 0) / expectedOutput.length;
    }

    predict(input) {
        // Forward propagate the input through the network to get the output
        this.forwardPropagate(input);

        // The output of the network is the prediction
        return this.finalOutputs;
    }
}

module.exports = NeuralNetwork;
